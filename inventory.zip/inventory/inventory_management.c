#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ITEMS 100
#define MAX_STR_LEN 50

typedef struct {
    int item_id;
    char name[MAX_STR_LEN];
    int quantity;
    float price;
} Item;

// Function prototypes
void add_item(Item inventory[], int *num_items);
void update_quantity(Item inventory[], int num_items);
void search_item(Item inventory[], int num_items);
void display_inventory_report(Item inventory[], int num_items);
int load_inventory(Item inventory[]);
int save_inventory(Item inventory[], int num_items);

int main() {
    Item inventory[MAX_ITEMS];
    int num_items = load_inventory(inventory);
    int choice;

    do {
        printf("\nInventory Management System\n");
        printf("1. Add Item\n");
        printf("2. Update Quantity\n");
        printf("3. Search Item\n");
        printf("4. Display Inventory Report\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: add_item(inventory, &num_items); break;
            case 2: update_quantity(inventory, num_items); break;
            case 3: search_item(inventory, num_items); break;
            case 4: display_inventory_report(inventory, num_items); break;
            case 5: break;
            default: printf("Invalid choice.\n");
        }
    } while (choice != 5);

    save_inventory(inventory, num_items);
    return 0;
}

void add_item(Item inventory[], int *num_items) {
    if (*num_items < MAX_ITEMS) {
        printf("Enter Item ID: ");
        scanf("%d", &inventory[*num_items].item_id);
        printf("Enter Item Name: ");
        scanf(" %[^\n]s", inventory[*num_items].name); // Important for reading strings with spaces
        printf("Enter Quantity: ");
        scanf("%d", &inventory[*num_items].quantity);
        printf("Enter Price: ");
        scanf("%f", &inventory[*num_items].price);
        (*num_items)++;
        printf("Item added successfully.\n");
    } else {
        printf("Inventory is full.\n");
    }
}

void update_quantity(Item inventory[], int num_items) {
    int item_id, new_quantity;
    printf("Enter Item ID to update: ");
    scanf("%d", &item_id);
    printf("Enter New Quantity: ");
    scanf("%d", &new_quantity);

    for (int i = 0; i < num_items; i++) {
        if (inventory[i].item_id == item_id) {
            inventory[i].quantity = new_quantity;
            printf("Quantity updated.\n");
            return;
        }
    }
    printf("Item not found.\n");
}

void search_item(Item inventory[], int num_items) {
    int item_id;
    printf("Enter Item ID to search: ");
    scanf("%d", &item_id);

    for (int i = 0; i < num_items; i++) {
        if (inventory[i].item_id == item_id) {
            printf("Item Found:\n");
            printf("ID: %d, Name: %s, Quantity: %d, Price: %.2f\n", inventory[i].item_id, inventory[i].name, inventory[i].quantity, inventory[i].price);
            return;
        }
    }
    printf("Item not found.\n");
}

void display_inventory_report(Item inventory[], int num_items) {
    float total_value = 0;
    printf("\nInventory Report\n");
    printf("--------------------------------------------------\n");
    printf("%-10s %-20s %-10s %-10s %-10s\n", "Item ID", "Name", "Quantity", "Price", "Total Value");
    printf("--------------------------------------------------\n");

    for (int i = 0; i < num_items; i++) {
        float item_value = inventory[i].quantity * inventory[i].price;
        printf("%-10d %-20s %-10d %-10.2f %-10.2f\n", inventory[i].item_id, inventory[i].name, inventory[i].quantity, inventory[i].price, item_value);
        total_value += item_value;
    }
    printf("--------------------------------------------------\n");
    printf("Total Inventory Value: %.2f\n", total_value);
}

int load_inventory(Item inventory[]) {
    FILE *file = fopen("inventory.txt", "r");
    int num_items = 0;

    if (file != NULL) {
        while (fscanf(file, "%d,%[^,],%d,%f", &inventory[num_items].item_id, inventory[num_items].name, &inventory[num_items].quantity, &inventory[num_items].price) == 4) {
            num_items++;
            if (num_items >= MAX_ITEMS) break; // Prevent buffer overflow
        }
        fclose(file);
    }
    return num_items;
}

int save_inventory(Item inventory[], int num_items) {
    FILE *file = fopen("inventory.txt", "w");

    if (file != NULL) {
        for (int i = 0; i < num_items; i++) {
            fprintf(file, "%d,%s,%d,%.1f\n", inventory[i].item_id, inventory[i].name, inventory[i].quantity, inventory[i].price);
        }
        fclose(file);
    }
    return 0; // 0 indicates success (you can add more error handling if needed)
}